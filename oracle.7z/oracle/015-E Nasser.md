number:	015
period:	E
name:	Nasser\*
side:	USSR
OPS:	1

^name:	-
^src:	-

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Add 2 USSR Influence in Egypt. Remove half (rounded up) of the US Influence in Egypt.

	oracle: [img url]

Remove USA influence from `Egypt` equal to half, rounded up, of the USA influence there.

Place 2 USSR influence in `Egypt`.