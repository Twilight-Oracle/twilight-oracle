number:	009
period:	E
name:	Vietnam Revolts\*
side:	USSR
OPS:	2

^name:	-
^src:	-

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Add 2 USSR Influence in Vietnam. For the remainder of the turn, the Soviet player may add 1 Operations point to any card that uses all points in Southeast Asia.

	oracle: [img url]

Place 2 USSR influence in `Vietnam`.

Until end of turn, the operations value of any card played by USSR is 1 greater if all its operations are performed in `Southeast Asia`.