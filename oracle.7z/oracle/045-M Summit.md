number:	045
period:	M
name:	Summit
side:	none
OPS:	1

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

Both players roll a die. Each adds 1 for each Region they Dominate or Control. High roller gains 2 VP and may move DEFCON marker one level in either direction. Do not reroll ties.

	oracle: [img url]

Each side rolls a die and adds 1 for each region other than `Western Europe`, `Eastern Europe`, and `Southeast Asia` in which it has domination or control.

If either side's result is greater, award that side 2 VP and that side may increment or decrement DEFCON up to once.
