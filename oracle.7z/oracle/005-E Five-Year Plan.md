number:	005
period:	E
name:	Five-Year Plan
side:	USA
OPS:	3

^name:	Soviet Announces a 5-Year Plan
^src:	New York Times 05.20.31

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

USSR player must randomly dicard one card. If the card is a US associated Event, the Event occurs immeditely. If the card is a USSR associated Event or an Event applicable to both players, then the card must be discarded without triggering the Event.

	oracle: [img url]

USSR chooses a card in its hand at random and discards it.

If that card is USA-aligned, USA resolves it.