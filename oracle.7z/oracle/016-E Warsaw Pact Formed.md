number:	016
period:	E
name:	Warsaw Pact Formed\*
side:	USSR
OPS:	3

^name:	-
^src:	-

scoring:	false
war:		false
unique:		true
continuous:	true

	print: [img url]

Remove all US Influence from four countries in Eastern Europe, or add 5 USSR Influence in Eastern Europe, adding no more than 2 per country. Allows play of *NATO*.

	oracle: [img url]

Perform one (USSR's choice):
* Remove all USA influence from up to 4 countries in `Eastern Europe`.
* Place 5 USSR influence in `Eastern Europe`. Do not place more than 2 influence in any single country.

*Ongoing* — `021-E NATO` can now be resolved.