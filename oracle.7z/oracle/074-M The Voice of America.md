number:	074
period:	M
name:	The Voice of America
side:	USA
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

Remove 4 USSR Influence from non-European countries. No more than 2 may be removed from any one country.

	oracle: [img url]

Remove 4 USSR influence from any combination of countries not in `Europe`. Do not remove more than 2 influence from any single country.
