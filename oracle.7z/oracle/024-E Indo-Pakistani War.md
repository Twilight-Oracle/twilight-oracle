number:	024
period:	E
name:	Indo-Pakistani War
side:	none
OPS:	2

^name:	-
^src:	-

scoring:	false
war:		true
unique:		false
continuous:	false

	print: [img url]

India or Pakistan invades the other (player's choice). Roll one die and subtract 1 for every opponent-controlled country adjacent to the target of the invasion. Player Victory on modified die roll of 4-6. Player adds 2 to Military Ops Track.

**Effects of Victory:** Player gains 2 VP and replaces all opponent's Influence in target country with his Influence.

	oracle: [img url]

Gain 2 military operations.

Choose `India` or `Pakistan`.

Roll a die and subtract 1 for each enemy-controlled country adjacent to the chosen country. If the result is 4 or greater, gain 2 VP, remove all enemy influence from the chosen country, and place friendly influence there equal to the amount removed.