number:	031
period:	E
name:	Red Scare—Purge
side:	none
OPS:	4

^name:	-
^src:	-

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

All further Operations cards played by your opponent this turn are -1 to their value (to a minimum value of 1 Op).

	oracle: [img url]

Until end of turn, the operations value of any card played by the enemy is 1 less. A card's operations value cannot be reduced below 1 in this way.