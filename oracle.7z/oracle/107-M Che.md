number:	107
period:	M
name:	Che
side:	USSR
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

USSR may immediately make a Coup attempt using this card's Operations value against a non-battleground country in Central America, South America, or Africa.

If the Coup removes any US Influence, USSR may make a second Coup attempt against a different target under the same restrictions.

	oracle: [img url]

USSR may launch a coup in a non-battleground country in `Central America`, `South America`, or `Africa` using this card.

If any USA influence is removed this way, USSR may launch a coup in a different non-battleground country in `Central America`, `South America`, or `Africa` using this card.
