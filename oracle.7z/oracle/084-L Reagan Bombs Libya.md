number:	084
period:	L
name:	Reagan Bombs Libya\*
side:	USA
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

US gains 1 VP for every 2 USSR influence in Libya.

	oracle: [img url]

Award USA an amount of VP equal to half the USSR influence in `Libya`, rounded down.
