number:	021
period:	E
name:	NATO\*
side:	USA
OPS:	4

^name:	-
^src:	-

scoring:	false
war:		false
unique:		true
continuous:	true

	print: [img url]

*Play after 'Marshall Plan' or 'Warsaw Pact.'*

USSR player may no longer make Coup or Realignment rolls in any US Controlled countries in Europe.

US Controlled countries in Europe may not be attacked by play of the *Brush War* event.

	oracle: [img url]

This card cannot be implemented except during `016-E Warsaw Pact Formed` or `023-E Marshall Plan`.

*Ongoing* — USSR cannot choose USA-controlled countries in `Europe` for coups, realignments, or `036-M Brush War`.