number:	050
period:	M
name:	We Will Bury You\*
side:	USSR
OPS:	4

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Unless *UN Intervention* is played as an Event on the US player's next round, USSR gains 3 VP prior to any US VP award.

Degrade DEFCON one level.

	oracle: [img url]

Decrement DEFCON.

When USA next plays a card in an action round, unless that card is `032-E UN Intervention` and USA chooses to resolve it, award USSR 3 VP.
