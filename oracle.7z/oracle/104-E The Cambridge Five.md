number:	104
period:	E
name:	The Cambridge Five
side:	USSR
OPS:	2

^name:	-
^src:	-

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

The US player exposes all scoring cards in their hand. The USSR player may then add 1 Influence in any single region named on one of these scoring cards (USSR choice). Cannot be played as an event in Late War.

	oracle: [img url]

If it is the Late War, this card does nothing.

Otherwise, USA reveals all scoring cards in their hand. USSR places 1 influence in a country in a region named on a card revealed this way.