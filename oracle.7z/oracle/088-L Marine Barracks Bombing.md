number:	088
period:	L
name:	Marine Barracks Bombing\*
side:	USSR
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Remove all US Influence in Lebanon plus remove 2 additional US Influence from anywhere in the Middle East.

	oracle: [img url]

Remove all USA influence from `Lebanon`.

Remove 2 USA influence from the `Middle East`.
