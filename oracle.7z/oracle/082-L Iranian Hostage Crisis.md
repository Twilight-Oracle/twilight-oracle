number:	082
period:	L
name:	Iranian Hostage Crisis\*
side:	USSR
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	true

	print: [img url]

Remove all US Influence in Iran. Add 2 USSR Influence in Iran.

Doubles effect of *Terrorism* card against US.

	oracle: [img url]

Remove all USA influence from `Iran`, then place 2 USSR influence there.

*Ongoing* — If USA would choose and discard a card due to the effects of `092-L Terrorism`, USA chooses and discards 2 cards instead.
