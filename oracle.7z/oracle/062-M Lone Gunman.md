number:	062
period:	M
name:	Lone Gunman\*
side:
OPS:

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

US Player reveals his hand.

Then the USSR may Conduct Operations as if they played a 1 Op card.

	oracle: [img url]

USA declares each card in its hand.

USSR conducts operations with this card.
