number:	051
period:	M
name:	Brezhnev Doctrine\*
side:	USSR
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

All further Operations cards played by the USSR this turn increase their OPs value by one (to a maximum of 4).

	oracle: [img url]

Until end of turn, the operations value of any card played by USSR is 1 greater. A card's operations value cannot exceed 4 in this way.
