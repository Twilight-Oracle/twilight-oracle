number:	093
period:	L
name:	Iran-Contra Scandal\*
side:	USSR
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

All US Realignment rolls have a -1 die roll modifier for the remainder of the turn.

	oracle: [img url]

Until end of turn, whenever either side performs a realignment, subtract 1 from the USA die roll.
