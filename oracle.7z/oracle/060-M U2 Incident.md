number:	060
period:	M
name:	U2 Incident\*
side:	USSR
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

USSR gains 1 VP.

If *UN Intervention* played later this turn as an Event, either by US or USSR, gain an additional 1 VP.

	oracle: [img url]

Award USSR 1 VP.

Until end of turn, when either side resolves `032-E UN Intervention`, award USSR 1 VP.
