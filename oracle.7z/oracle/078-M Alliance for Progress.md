number:	078
period:	M
name:	Alliance for Progress\*
side:	USA
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

US gains 1 VP for each US controlled Battleground country in Central America and South America.

	oracle: [img url]

For each USA-controlled battleground in `Central America` or `South America`, award USA 1 VP.
