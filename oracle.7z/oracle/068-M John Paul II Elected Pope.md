number:	068
period:	M
name:	John Paul II Elected Pope\*
side:	USA
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	true

	print: [img url]

Remove 2 USSR Influence in Poland and then add 1 US Influence in Poland.

*Allows play of 'Solidarity'.*

	oracle: [img url]

Remove 2 USSR influence from `Poland`, then place 1 USA influence there.

*Ongoing* — `101-L Solidarity` can now be resolved.
