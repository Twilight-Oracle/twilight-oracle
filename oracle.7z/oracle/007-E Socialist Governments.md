number:	007
period:	E
name:	Socialist Governments
side:	USSR
OPS:	3

^name:	-
^src:	-

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

*Unplayable as an event if 'The Iron Lady' is in effect.*

Remove US Influence in Western Europe by a total of 3 Influence points, removing no more than 2 per country.

	oracle: [img url]

Remove up to 3 USA influence from `Western Europe`. Do not remove more than 2 from any single country.

*(This card instead does nothing during `083-L The Iron Lady`.)*