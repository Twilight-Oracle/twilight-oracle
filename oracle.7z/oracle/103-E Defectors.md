number:	103
period:	E
name:	Defectors
side:	USA
OPS:	2

^name:	-
^src:	-

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

Play in Headline Phase to cancel USSR Headline event, including Scoring Card. Canceled card returns to Discard Pile.

If *Defectors* played by USSR during Soviet action round, US gains 1 VP (unless played on the Space Race).

	oracle: [img url]

If this card is a headline, it is valued above any other card and has the text "discard the USSR headline."

If this card is played by USSR in an action round, it has the text "award USA 1 VP."