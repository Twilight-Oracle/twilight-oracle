number:	012
period:	E
name:	Romanian Abdication\*
side:	USSR
OPS:	1

^name:	-
^src:	-

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Remove all US Influence from Romania. USSR gains sufficient Influence in Romania for Control.

	oracle: [img url]

Remove all USA influence from `Romania`.

Place USSR influence in `Romania` sufficient for control.