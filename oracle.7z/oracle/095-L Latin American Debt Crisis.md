number:	095
period:	L
name:	Latin American Debt Crisis
side:	USSR
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

Unless the US Player immediately discards a '3' or greater Operations card, double USSR Influence in two countries South America.

	oracle: [img url]

USA may discard a card with an operations value of 3 or greater. If USA does not, USSR chooses 2 countries in `South America` and places in each chosen country influence equal to the amount of USSR influence in that country.
