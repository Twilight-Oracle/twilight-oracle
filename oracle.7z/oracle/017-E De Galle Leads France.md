number:	017
period:	E
name:	De Gaulle Leads France\*
side:	USSR
OPS:	3

^name:	-
^src:	-

scoring:	false
war:		false
unique:		true
continuous:	true

	print: [img url]

Remove 2 US Influence in France, add 1 USSR Influence. Cancels effects of *NATO* for France.

	oracle: [img url]

Remove up to 2 USA influence from `France`.

Place 1 USSR influence in `France`.

*Ongoing* — *NATO* does not apply to `France`.