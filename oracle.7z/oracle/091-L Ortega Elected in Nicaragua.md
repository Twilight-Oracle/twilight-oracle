number:	091
period:	L
name:	Ortega Elected in Nicaragua\*
side:	USSR
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Remove all US Influence from Nicaragua. Then USSR may make one free Coup attempt (with this card's Operations value) in a country adjacent to Nicaragua.

	oracle: [img url]

Remove all USA influence from `Nicaragua`.

Choose a country adjacent to `Nicaragua`; you may launch a coup in that country using this card, but you gain no military operations.
