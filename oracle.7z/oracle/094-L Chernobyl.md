number:	094
period:	L
name:	Chernobyl\*
side:	USA
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

The US player may designate one Region. For the remainder of the turn the USSR may not add additional Influence to that Region by the play of Operations Points via placing Influence.

	oracle: [img url]

USA names a region. Until end of turn, USSR may not spread influence in any country in that region.
