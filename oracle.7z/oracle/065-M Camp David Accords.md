number:	065
period:	M
name:	Camp David Accords\*
side:	USA
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	true

	print: [img url]

US gains 1 VP.

US receives 1 Influence in Israel, Jordan and Egpyt.

*'Arab-Israeli War' event no longer playable.*

	oracle: [img url]

Award USA 1 VP.

Place 1 USA influence in each of `Israel`, `Jordan`, and `Egypt`.

*Ongoing* — `013-E Arab-Israeli War` does nothing.
