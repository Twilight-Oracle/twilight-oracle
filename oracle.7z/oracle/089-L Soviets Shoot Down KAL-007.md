number:	089
period:	L
name:	Soviets Shoot Down KAL-007\*
side:	USA
OPS:	4

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Degrade DEFCON one level. US gains 2 VP.

If South Korea is US Controlled, then the US may place Influence or attempt Realignments as if they played a 4 Ops card.

	oracle: [img url]

Decrement DEFCON, then award USA 2 VP.

If `South Korea` is USA-controlled, USA may spread influence or perform realignments with this card.
