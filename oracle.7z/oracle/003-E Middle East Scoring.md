number:	003
period:	E
name:	Middle East Scoring
side:	none
OPS:	-

^name:	-
^src:	-

scoring:	true
war:		false
unique:		false
continuous:	false

	print: [img url]

-

	oracle: [img url]

Score the `Middle East`.