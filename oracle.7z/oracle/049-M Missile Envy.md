number:	049
period:	M
name:	Missile Envy
side:	none
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

Exchange this card for your opponent's highest valued Operations card in his hand. If two or more cards are tied, opponent chooses.

If the exchanged card contains your event, or an event applicable to both players, it occurs immediately. If it contains opponent's event, use Operations value without triggering event. Opponent must use this card for Operations during his next action round.

	oracle: [img url]

The enemy chooses a card from among the cards in its hand which have the greatest operations value. If the chosen card is aligned with the enemy, you conduct operations with that card. Otherwise, you resolve that card.

Then, put this card in the enemy's hand. The enemy must choose to play this card the next time they complete an action round. The enemy must choose to conduct operations with this card when they play it.
