number:	106
period:	E
name:	NORAD*
side:	USA
OPS:	3

^name:	-
^src:	-

scoring:	false
war:		false
unique:		true
continuous:	true

	print: [img url]

If the US controls Canada, the US may place 1 Influence in any country already containing US Influence at the conclusion of any Action Round in which the DEFCON marker moves to the '2' box. This event canceled by *#42 Quagmire*.

	oracle: [img url]

*Ongoing* — After either side completes an action round, if DEFCON became 2 during that action round, USA may place 1 influence in any country containing USA influence.

*(`042-M Quagmire` ends this event.)*