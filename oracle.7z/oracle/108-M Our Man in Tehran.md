number:	108
period:	M
name:	Our Man in Tehran
side:	USA
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

If the US controls at least one Middle East country, the US player draws the top 5 cards from the draw pile. They may reveal and then discard any or all of these drawn cards without triggering the Event. Any remaining drawn cards are returned to the draw deck, and it is reshuffled.

	oracle: [img url]

If USA controls any country in the `Middle East`, USA looks at the top 5 cards of the draw pile. USA may discard any of these cards.

If any card seen in this way was not discarded, shuffle the draw pile.
