number:	043
period:	M
name:	SALT Negotiations\*
side:	none
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Improve DEFCON two levels.

Further Coup attempts incur -1 die roll modifier for both players for the remainder of the turn.

Player may sort through discard pile and reclaim one non-scoring card, after revealing it to their opponent.

	oracle: [img url]

Increment DEFCON twice.

Choose a card in the discard pile and add it to your hand.

Until end of turn, when any side launches a coup, subtract 1 from that side's die roll.
