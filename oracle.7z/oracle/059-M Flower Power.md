number:	059
period:	M
name:	Flower Power\*
side:	USSR
OPS:	4

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	true

	print: [img url]

USSR gains 2 VP for every subsequently US played "war card" (played as an event or Operations) unless played on the space race. War Cards: *Arab-Israeli War, Korean War, Brush War, Indo-Pakistani War or Iran-Iraq War.*

*This event canceled by 'An Evil Empire'.*

	oracle: [img url]

*Ongoing* — When USA resolves a war card, award USSR 2 VP.

*(The war cards are `011-E`, `013-E`, `024-E`, `036-M`, and `102-L`.)*

*(This card instead does nothing during `097-L An Evil Empire`.)*

*(`097-L An Evil Empire` ends this event.)*
