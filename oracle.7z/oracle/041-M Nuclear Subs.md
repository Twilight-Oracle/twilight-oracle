number: 041
period:	M
name:	Nuclear Subs\*
side:	USA
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

US Coup attempts in Battleground Countries do not affect the DEFCON tract for the remainder of the turn (does not affect *Cuban Missile Crisis*).

	oracle: [img url]

Until end of turn, when USA launches a coup in a battleground, do not decrement DEFCON.

*(This does not prevent USA from losing the game to `040-M Cuban Missile Crisis`.)*
