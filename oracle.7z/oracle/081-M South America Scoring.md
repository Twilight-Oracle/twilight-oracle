number:	081
period:	M
name:	South America Scoring
side:	none
OPS:	-

^name:	-
^src:	-

scoring:	true
war:		false
unique:		false
continuous:	false

	print: [img url]

-

	oracle: [img url]

Score `South America`.