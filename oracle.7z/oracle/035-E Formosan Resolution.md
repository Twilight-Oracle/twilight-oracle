number:	035
period:	E
name:	Formosan Resolution\*
side:	USA
OPS:	2

^name:	-
^src:	-

scoring:	false
war:		false
unique:		true
continuous:	true

	print: [img url]

Taiwan shall be treated as a Battleground country for scoring purposes, if the US controls Taiwan when the Asia Scoring Card is played or during Final Scoring at the end of Turn 10. Taiwan is not a Battleground country for any other game purpose. This card is discarded after US play of *The China Card*.

	oracle: [img url]

*Ongoing* — When `Asia` is scored, if `Taiwan` is USA-controlled, `Taiwan` is a battleground during that scoring.

*(`Taiwan` is not a battleground at any other time.)*

*(`006-E The China Card` can end `035-E Formosan Resolution`.)*