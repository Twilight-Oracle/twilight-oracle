number:	100
period:	L
name:	Wargames\*
side:	none
OPS:	4

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

If DEFCON Status 2, you may immediately end the game (without Final Scoring Phase) after giving opponent 6 VPs.

	oracle: [img url]

If DEFCON is 2, you may award the enemy 6 VP.

If you do, the game ends. The side with more VP wins.
