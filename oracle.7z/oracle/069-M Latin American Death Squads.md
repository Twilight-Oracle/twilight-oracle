number:	069
period:	M
name:	Latin American Death Squads
side:	none
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

All of the player's Coup attempts in Central and South America are +1 for the remainder of the turn, while all opponent's Coup attempts are -1 for the remainder of the turn.

	oracle: [img url]

Until end of turn, when you launch a coup in a country in `Central America` or `South America`, add 1 to the die roll.

Until end of turn, when the enemy launches a coup in a country in `Central America` or `South America`, subtract 1 from the die roll.
