number:	076
period:	M
name:	Ussuri River Skirmish\*
side:	USA
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

If the USSR has *The China Card*, claim it face up and available for play. If the US already has *The China Card*, add 4 US Influence in Asia, no more than 2 per country.

	oracle: [img url]

If USA holds `006-E The China Card`, place 4 USA influence in `Asia`. Do not place more than 2 influence in any single country.

USA now holds `006-E The China Card`. Turn it faceup if it was taken from USSR.
