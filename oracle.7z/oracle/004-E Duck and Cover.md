number:	004
period:	E
name:	Duck and Cover
side:	USA
OPS:	3

^name:	"Duck and Cover" to Be Shown to School Children
^src:	New York Times 01.25.52

scoring:	false
war:		false
unique:		false
continuous:	false

	print:	[img url]

Degrade DEFCON one level.

Then US player earns VPs equal to 5 minus current DEFCON level.

	oracle: [img url]

Decrement DEFCON.

Award USA VP equal to five minus DEFCON.