number:	030
period:	E
name:	Decolonization
side:	USSR
OPS:	2

^name:	-
^src:	-

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

Add one USSR Influence in each of any four African and/or SE Asian countries.

	oracle: [img url]

Place 1 USSR influence in each of up to 4 countries in `Africa` or `Southeast Asia`.