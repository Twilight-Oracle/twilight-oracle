number:	006
period:	E
name:	The China Card
side:	none
OPS:	4

^name:	-
^src:	-

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

***Begins the game with the USSR player.***

+1 Operations value when all points are used in Asia. Pass to opponent after play.

+1 VP for the player holding this card at the end of Turn 10.

*Cancels effect of 'Formosan Resolution' if this card is played by the US player.*

	oracle: [img url]

Conduct operations with this card. This card's operations value is 1 greater if all its operations are conducted in `Asia`.

The enemy now holds this card. Turn it facedown.

When USA resolves this card, end `035-E Formosan Resolution\*`.

*(This card is never in a side's hand and cannot be discarded.)*
