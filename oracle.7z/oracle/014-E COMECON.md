number:	014
period:	E
name:	COMECON\*
side:	USSR
OPS:	3

^name:	-
^src:	-

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Add 1 USSR Influence in each of four non-US Controlled countries in Eastern Europe.

	oracle: [img url]

Place 1 USSR influence in each of up to 4 countries in `Eastern Europe` that are not USA-controlled.
