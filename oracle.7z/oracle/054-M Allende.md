number:	054
period:	M
name:	Allende\*
side:	USSR
OPS:	1

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

USSR receives 2 Influence in Chile.

	oracle: [img url]

Place 2 USSR influence in `Chile`.
