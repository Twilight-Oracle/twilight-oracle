number:	013
period:	E
name:	Arab-Israeli War
side:	USSR
OPS:	2

^name:	-
^src:	-

scoring:	false
war:		true
unique:		false
continuous:	false

	print: [img url]

A Pan-Arab Coalition invades Israel. Roll one die and subtract 1 for US Control of Israel and every US-controlled country adjacent to Israel. USSR Victory on modified die roll 4-6. USSR adds 2 to Military Ops Track.

**Effects of Victory:** USSR gains 2 VP and replaces all US Influence in Israel with USSR Influence.

	oracle: [img url]

Award USSR 2 military operations.

Roll a die and subtract 1 for each of `Israel` and its adjacent countries that is USA-controlled. If the result is 4 or greater, award 2 VP to USSR, remove all USA influence from `Israel`, and place USSR influence there equal to the amount removed.

*(This card instead does nothing during `065-M Camp David Accords`.)*
