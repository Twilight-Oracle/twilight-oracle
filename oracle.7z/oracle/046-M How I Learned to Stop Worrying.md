number:	046
period:	M
name:	How I Learned to Stop Worrying\*
side:	none
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Set the DEFCON at any level you want (1-5). This event counts as 5 Military Operations for the purpose of required Military Operations.

	oracle: [img url]

Gain 5 military operations.

Move the DEFCON marker to any step of the DEFCON track.
