number:	044
period:	M
name:	Bear Trap\*
side:	USA
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	true

	print: [img url]

On next action round, USSR player must discard an Operations card worth 2 or more *and* roll 1-4 to cancel this event. Repeat each USSR player Action Round until successful or no appropriate cards remain. If out of appropriate cards, the USSR player may only play scoring cards until the next turn.

	oracle: [img url]

*Ongoing* — USSR may only play scoring cards or cards from hand with operations values of 2 or greater. If USSR has no such cards in hand, USSR must choose to play no card in an action round.

*Ongoing* — Whenever USSR plays a card with an operations value, instead of choosing a use for that card, USSR discards it and rolls a die. On a result of 4 or less, all of this card's effects end.

*(Discarded cards are not resolved.)*
