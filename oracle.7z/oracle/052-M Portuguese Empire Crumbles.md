number:	052
period:	M
name:	Portuguese Empire Crumbles\*
side:	USSR
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Add 2 USSR Influence in both the SE African States and Angola.

	oracle: [img url]

Place 2 USSR influence in each of `SE African States` and `Angola`.
