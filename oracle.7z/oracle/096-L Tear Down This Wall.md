number:	096
period:	L
name:	Tear Down This Wall\*
side:	USA
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	true

	print: [img url]

Cancels/prevents *Willy Brandt*.

Add 3 US Influence in East Germany.

Then US may make a free Coup attempt or Realignment rolls in Europe using this card's Ops Value.

	oracle: [img url]

Place 3 USA influence in `East Germany`.

USA may launch a coup or perform realignments in `Europe` using this card, ignoring DEFCON restrictions, but gains no military operations.

End `055-M Willy Brandt`.

*Ongoing* — `055-M Willy Brandt` does nothing.
