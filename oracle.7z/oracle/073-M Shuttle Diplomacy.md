number:	073
period:	M
name:	Shuttle Diplomacy
side:	USA
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

Play in front of US player. During the next scoring of the Middle East or Asia (whichever comes first), subtract one Battleground country from USSR total, then put this card in the discard pile. Does not count for Final Scoring at the end of Turn 10.

	oracle: [img url]

When either `Asia` or the `Middle East` is scored, if Final Scoring is not ongoing, USA chooses a USSR-controlled battleground in that region. Score the region as though the chosen country did not exist. Then discard this card.

*(From the time this card is resolved until this card instructs that it is to be discarded, instead of discarding it, place it faceup in front of USA.)*
