number:	048
period:	M
name:	Kitchen Debates\*
side:	USA
OPS:	1

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

If the US controls more Battleground countries than the USSR, poke opponent in chest and gain 2 VP!

	oracle: [img url]

If USA controls more battlegrounds than USSR, award USA 2 VP.
