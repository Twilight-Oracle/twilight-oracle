number:	098
period:	L
name:	Aldrich Ames Remix\*
side:	USSR
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

US player exposes his hand to USSR player for remainder of turn. USSR then chooses one card from US hand; this card is discarded.

	oracle: [img url]

Until end of turn, USA plays with its hand revealed.

USSR chooses a card from USA's hand. USA discards that card.
