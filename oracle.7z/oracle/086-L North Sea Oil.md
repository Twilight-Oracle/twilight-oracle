number:	086
period:	L
name:	North Sea Oil\*
side:	USA
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	true

	print: [img url]

*OPEC* event is no longer playable.

US may play 8 cards this turn.

	oracle: [img url]

USA must complete 8 action rounds this turn. In its 8th action round, USA may decline to play a card.

*Ongoing* — `061-M OPEC` does nothing.
