number:	010
period:	E
name:	Blockade\*
side:	USSR
OPS:	1

^name:	-
^src:	-

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Unless US Player immediately discards a '3' or more value Operations card, eliminate all US Influence in West Germany.

	oracle: [img url]

USA may discard a card with an operations value of 3 or greater. If USA does not, remove all USA influence from `West Germany`.