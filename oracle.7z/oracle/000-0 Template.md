number:
period:
name:
side:
OPS:

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

Text.

	oracle: [img url]

Text.
