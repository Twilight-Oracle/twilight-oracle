number:	008
period:	E
name:	Fidel\*
side:	USSR
OPS:	3

^name:	-
^src:	-

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Remove all US Influence in Cuba. USSR gains sufficient Influence in Cuba for Control.

	oracle: [img url]

Remove all US influence from `Cuba`.

Place USSR influence in `Cuba` sufficient for control.