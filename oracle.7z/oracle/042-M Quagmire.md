number:	042
period:	M
name:	Quagmire\*
side:	USSR
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	true

	print: [img url]

On next action round, US player must discard an Operations card worth 2 or more *and* roll 1-4 to cancel this event. Repeat each US player Action round until successful or no appropriate cards remain. If out of appropriate cards, the US player may only play scoring cards until the next turn.

	oracle: [img url]

End the effects of `106-E NORAD`.

*Ongoing* — USA may only play scoring cards or cards from hand with operations values of 2 or greater. If USA has no such cards in hand, USA must choose to play no card in an action round.

*Ongoing* — Whenever USA plays a card with an operations value, instead of choosing a use for that card, USA discards it and rolls a die. On a result of 4 or less, all of this card's effects end.

*(Discarded cards are not resolved.)*
