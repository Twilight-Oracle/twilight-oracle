number:	063
period:	M
name:	Colonial Rear Guards
side:	USA
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

Add 1 US Influence in each of four different African and/or Southeast Asian countries.

	oracle: [img url]

Place 1 USA influence in each of up to 4 countries in `Africa` or `Southeast Asia`.
