number:	001
period:	E
name:	Asia Scoring
side:	none
OPS:	-

^name:	-
^src:	-

scoring:	true
war:		false
unique:		false
continuous:	false

	print: [img url]

-

	oracle: [img url]

Score `Asia`.