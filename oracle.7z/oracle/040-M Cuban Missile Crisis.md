number:	040
period:	M
name:	Cuban Missile Crisis\*
side:	none
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Set DEFCON to Level 2. Any further Coup attempt by your opponent this turn, anywhere on the board, will result in Global Thermonuclear War. Your opponent will lose the game. This event may be canceled at any time if the USSR player removes two Influence from Cuba or the US player removes 2 Influence from either West Germany or Turkey.

	oracle: [img url]

Set DEFCON to 2.

Until end of turn, if the enemy launches a coup, that side loses the game.

Until end of turn, at any time, USSR may remove 2 friendly influence from `Cuba` and USA may remove 2 friendly influence from either `West Germany` or `Turkey`; if either side removes friendly influence this way, all of this card's effects end.
