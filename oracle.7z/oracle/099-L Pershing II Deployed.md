number:	099
period:	L
name:	Pershing II Deployed\*
side:	USSR
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

USSR gains 1 VP.

Remove 1 US Influence from up to three countries in Western Europe.

	oracle: [img url]

Award USSR 1 VP.

Remove 1 USA influence from each of up to 3 countries in `Western Europe`.
