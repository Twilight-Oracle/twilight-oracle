number:	036
period:	M
name:	Brush War
side:	none
OPS:	3

^name:
^src:

scoring:	false
war:		true
unique:		false
continuous:	false

	print: [img url]

Attack any country with a stability of 1 or 2. Roll a die and subtract 1 for every adjacent enemy controlled country. Success on 3-6. Player adds 3 to his Military OPs Track.

	oracle: [img url]

Gain 3 military operations.

Choose a country with stability less than 3. Roll a die and subtract 1 for each enemy-controlled country adjacent to the chosen country. If the result is 4 or greater, gain 1 VP, remove all enemy influence from the chosen country, and place friendly influence there equal to the amount removed.
