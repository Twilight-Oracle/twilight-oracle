number:	018
period:	E
name:	Captured Nazi Scientist\*
side:	none
OPS:	1

^name:	-
^src:	-

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Advance player's Space Race marker one box.

	oracle: [img url]

Advance your Space Race marker one step.