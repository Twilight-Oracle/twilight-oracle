number:	092
period:	L
name:	Terrorism
side:	none
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

Opponent must randomly discard one card. If played by USSR and *Iranian Hostage Crisis* is in efect, the US player must randomly discard two cards.

(Events on discard do not occur.)

	oracle: [img url]

The enemy chooses a card from its hand at random and discards that card.

*(`082-L Iranian Hostage Crisis` causes USA to discard 2 cards instead of 1.)*
