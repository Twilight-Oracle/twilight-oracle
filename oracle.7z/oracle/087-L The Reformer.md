number:	087
period:	L
name:	The Reformer\*
side:	USSR
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	true

	print: [img url]

Add 4 Influence in Europe (no more than 2 per country). If USSR is ahead of US in VP, then 6 Influence may be added instead.

USSR may no longer conduct Coup attempts in Europe.

*Improves effect of 'Glasnost' event.*

	oracle: [img url]

Perform one (USSR's choice):
* Place 4 USSR influence in `Europe`.
* If USSR has more VP than USA, place 6 USSR influence in `Europe`.

Do not place more than 2 influence in a single country.

*Ongoing* — USSR may not choose any country in `Europe` when launching a coup.

*Ongoing* — After USSR resolves `090-L Glasnost`, USSR may spread influence or perform realignments with that card.
