number:	032
period:	E
name:	UN Intervention
side:	none
OPS:	1

^name:	-
^src:	-

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

Play this card simultaneously with a card containing your opponent's associated Event. The Event is canceled, but you may use its Operations value to Conduct Operations. The canceled event card returns to the discard pile. May not be played during headline phase.

	oracle: [img url]

If this card is a headline, it does nothing.

Otherwise, discard a card aligned with the enemy. Conduct operations with that card.

*(That card is not resolved. Neutral cards are aligned with neither side.)*