number:	027
period:	E
name:	US-Japan Mutual Defense Pact\*
side:	USA
OPS:	4

^name:	-
^src:	-

scoring:	false
war:		false
unique:		true
continuous:	true

	print: [img url]

US gains sufficient Influence in Japan for Control.

USSR may no longer may Coup or Realignment rolls in Japan.

	oracle: [img url]

Place USA influence in `Japan` sufficient for control.

*Ongoing* — USSR cannot choose `Japan` for coups or realignments.