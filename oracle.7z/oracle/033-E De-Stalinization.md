number:	033
period:	E
name:	De-Stalinization\*
side:	USSR
OPS:	3

^name:	-
^src:	-

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

USSR may relocate up to 4 Influence points to non-US controlled countries.

No more than 2 influence may be placed in the same country.

	oracle: [img url]

Choose any number of countries. Remove up to 4 USSR influence from among them.

Place USSR influence equal to the amount removed, divided among any number of countries not USA-controlled. Do not place more than 2 influence in any single country.