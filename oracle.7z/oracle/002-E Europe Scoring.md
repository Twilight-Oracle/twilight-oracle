number:	002
period:	E
name:	Europe Scoring
side:	none
OPS:	-

^name:	-
^src:	-

scoring:	true
war:		false
unique:		false
continuous:	false

	print: [img url]

-

	oracle: [img url]

Score `Europe`.