number:	029
period:	E
name:	East European Unrest
side:	USA
OPS:	3

^name:	-
^src:	-

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

**In Early or Mid War:** Remove 1 USSR Influence from three countries in Eastern Europe.

**In Late War:** Remove 2 USSR Influence from three countries in Eastern Europe.

	oracle: [img url]

Remove 1 USSR influence from each of up to 3 countries in `Eastern Europe`.

If it is the Late War, instead remove up to 2 USSR influence from those countries.