number:	026
period:	E
name:	CIA Created\*
side:	USA
OPS:	1

^name:	-
^src:	-

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

USSR reveals hand this turn.

Then the US may Conduct Operations as if they played a 1 Op card.

	oracle: [img url]

Until end of turn, USSR plays with its hand revealed.

USA conducts operations with this card.