number:	101
period:	L
name:	Solidarity\*
side:	USA
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

*Playable as an event only if 'John Paul II Elected Pope' is in effect.*

Add 3 US Influence in Poland.

	oracle: [img url]

Place 3 USA influence in `Poland`.

If `068-M John Paul II Elected Pope` is not ongoing, this card instead does nothing.
