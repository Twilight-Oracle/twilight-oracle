number:	047
period:	M
name:	Junta
side:	none
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

Place 2 Influence in any one Central or South American country.

Then you may make a free Coup attempt or Realignment roll in one of these regions (using this card's Operations Value).

	oracle: [img url]

Place 2 influence in a country in `Central America` or `South America`.

Choose a country in `Central America` or `South America`; you may launch a coup in that country using this card, but you gain no military operations.
