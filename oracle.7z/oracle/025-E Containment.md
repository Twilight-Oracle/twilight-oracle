number:	025
period:	E
name:	Containment\*
side:	USA
OPS:	3

^name:	-
^src:	-

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

All further Operations cards played by US this turn add one to their value (to a maximum of 4).

	oracle: [img url]

Until end of turn, the operations value of any card played by USA is 1 greater. A card's operations value cannot exceed 4 in this way.