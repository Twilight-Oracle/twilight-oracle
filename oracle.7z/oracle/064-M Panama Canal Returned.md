number:	064
period:	M
name:	Panama Canal Returned\*
side:	USA
OPS:	1

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Add 1 US Influence in Panama, Costa Rica, and Venezuela.

	oracle: [img url]

Place 1 USA influence in each of `Panama`, `Costa Rica`, and `Venezuela`.
