number:	067
period:	M
name:	Grain Sales to Soviets
side:	USA
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

Randomly choose one card from USSR hand. Play it or return it. If Soviet player has no card, or returned, use this card to conduct Operations normally.

	oracle: [img url]

USSR chooses a card in its hand at random and declares it.

Perform one (USA's choice):
* USA plays the declared card.
* USA conducts operations with this card.
