number:	056
period:	M
name:	Muslim Revolution
side:	USSR
OPS:	4

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

Remove all US Influence in two of the following countries: Sudan, Iran, Iraq, Egypt, Libya, Saudi Arabia, Syria, Jordan.

	oracle: [img url]

Choose 2 of `Sudan`, `Iran`, `Iraq`, `Egypt`, `Libya`, `Saudi Arabia`, and `Jordan`.

Remove all USA influence from the chosen countries.

*(This card instead does nothing during `110-L AWACS Sale to Saudis`.)*
