number:	110
period:	L
name:	AWACS Sale to Saudis\*
side:	USA
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	true

	print: [img url]

US receives 2 Influence in Saudi Arabia. Muslim Revolution may no longer be played as an event.

	oracle: [img url]

Place 2 USA influence in `Saudi Arabia`.

*Ongoing* — `065-M Muslim Revolution` does nothing.
