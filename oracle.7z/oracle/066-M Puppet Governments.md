number:	066
period:	M
name:	Puppet Governments\*
side:	USA
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

US may add 1 Influence in three countries that currently contain no Influence from either power.

	oracle: [img url]

Place 1 USA influence in each of up to 3 countries which contain no influence.
