number:	077
period:	M
name:	Ask Not What Your Country Can Do For You\*
side:	USA
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

US player may discard up to entire hand (including Scoring cards) and draw replacements from the deck. The number of cards discarded must be decided prior to drawing any replacements.

	oracle: [img url]

USA chooses any number of cards in its hand. USA discards those cards, then draws a number of cards equal to the number discarded this way.
