number:	085
period:	L
name:	Star Wars
side:	USA
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

If the US is ahead on the Space Race track, play this card to search through the discard pile for a non-scoring card of your choice. Event occurs immediately.

	oracle: [img url]

If USA's Space Race marker is ahead of USSR's, USA chooses a card in the discard pile other than a scoring card and resolves that card.
