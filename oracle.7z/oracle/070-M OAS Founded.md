number:	070
period:	M
name:	OAS Founded\*
side:	USA
OPS:	1

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Add 2 US Influence in Central America and/or South America.

	oracle: [img url]

Place 2 USA influence in any combination of countries in `Central America` and `South America`.
