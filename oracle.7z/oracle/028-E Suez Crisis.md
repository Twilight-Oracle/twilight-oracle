number:	028
period:	E
name:	Suez Crisis\*
side:	USSR
OPS:	3

^name:	-
^src:	-

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Remove a total of 4 US Influence from France, the United Kingdom and Israel. Remove no more than 2 Influence per country.

	oracle: [img url]

Remove up to 4 USA influence from `France`, the `United Kingdom`, and `Israel`. Do not remove more than 2 from any single country.