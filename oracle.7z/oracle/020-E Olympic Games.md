number:	020
period:	E
name:	Olympic Games
side:	none
OPS:	2

^name:	-
^src:	-

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

Player sponsors Olympics. Opponent may participate or boycott. If Opponent participates, each player rolls one die, with the sponsor adding 2 to his roll. High roll gains 2 VP. Reroll ties. If Opponent boycotts, degrade DEFCON one level and the Sponsor may Conduct Operations as if they played a 4 Ops card.

	oracle: [img url]

Perform one (enemy's choice):
* Roll a die and add 2. The enemy rolls a die. Repeat both rolls until one side has a greater result. Award 2 VP to that side.
* Decrement DEFCON. Conduct operations with this card as though its operations value were 4.