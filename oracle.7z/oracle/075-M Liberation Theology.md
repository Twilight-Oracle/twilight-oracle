number:	075
period:	M
name:	Liberation Theology
side:	USSR
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

Add 3 USSR Influence in Central America, no more than 2 per country.

	oracle: [img url]

Place 3 USSR influence in `Central America`. Do not place more than 2 influence in any single country.
