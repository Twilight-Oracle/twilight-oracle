number:	019
period:	E
name:	Truman Doctrine\*
side:	USA
OPS:	1

^name:	-
^src:	-

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Remove all USSR Influence markers in one uncontrolled country in Europe.

	oracle: [img url]

Remove all USSR influence from an uncontrolled country in `Europe`.