number:	061
period:	M
name:	OPEC
side:	USSR
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

USSR gains 1 VP for each of the following countries he controls:

Egypt, Iran, Libya, Saudi Arabia, Iraq, Gulf States, and Venezuela.

*Unplayable as an event if 'North Sea Oil' is in effect.*

	oracle: [img url]

For each of `Egypt`, `Iran`, `Libya`, `Saudi Arabia`, `Iraq`, `Gulf States`, and `Venezuela` which USSR controls, award USSR 1 VP.

*(This card instead does nothing during `086-L North Sea Oil`.)*
