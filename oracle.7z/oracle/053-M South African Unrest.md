number:	053
period:	M
name:	South African Unrest
side:	USSR
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

USSR either adds 1 Influence in South Africa or adds 1 Influence in South Africa and 2 Influence in any countries adjacent to South Africa.

	oracle: [img url]

Place 1 USSR influence in `South Africa`.

Perform one (USSR's choice):
* Place 1 USSR influence in `South Africa`.
* Place 2 USSR influence divided among any number of countries adjacent to `South Africa`.
