number:	105
period:	E
name:	Special Relationship
side:	USA
OPS:	2

^name:	-
^src:	-

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

If US is US controlled but NATO is not in effect, US adds 1 Influence to any country adjacent to the UK.

If UK is US controlled and NATO is in effect, US adds 2 Influence to any Western European country and gains 2 VPs.

	oracle: [img url]

If the `United Kingdom` is not USA-controlled, this card does nothing.

Otherwise, perform one (USA's choice):
* Place 1 USA influence in any country adjacent to the `United Kingdom`.
* If `021-E NATO` is in effect, place 2 USA influence in any country in `Western Europe` and award USA 2 VP.