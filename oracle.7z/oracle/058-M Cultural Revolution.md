number:	058
period:	M
name:	Cultural Revolution\*
side:	USSR
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

If the US has *The China Card*, claim it face up and available for play. If the USSR already has it, USSR gains 1 VP.

	oracle: [img url]

If USSR holds `006-E The China Card`, award USSR 1 VP.

USSR now holds `006-E The China Card`. Turn it faceup if it was taken from USA.
