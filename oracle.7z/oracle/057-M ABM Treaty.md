number:	057
period:	M
name:	ABM Treaty
side:	none
OPS:	4

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

Improve DEFCON one level.

Then player may Conduct Operations as if they played a 4 Ops card.

	oracle: [img url]

Increment DEFCON.

Conduct operations with this card.
