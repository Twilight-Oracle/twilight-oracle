number:	080
period:	M
name:	One Small Step
side:	none
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

If you are behind on the Space Race track, play this card to move your marker two boxes forward on the Space Race Track, gaining the VP value of the second box only.

	oracle: [img url]

If your Space Race marker is behind the enemy's, advance your Space Race marker twice. Do not claim any VP award for the first of these advances.
