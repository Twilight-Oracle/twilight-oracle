number:	039
period:	M
name:	Arms Race
side:	none
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

Compare each player's status on the Military Operations Tracks. If Phasing Player has more MIlitary Operations points, he scores 1 VP. If Phasing Player has more Military Operations points *and* has met the Required Military Operations amount, he scores 3 VP instead.

	oracle: [img url]

If the active side's MilOps marker is ahead of its enemy's, award the active side 1 VP.

If the active side's MilOps marker is ahead of its enemy's and is on a step that meets or exceeds DEFCON in value, award that side 2 additional VP.
