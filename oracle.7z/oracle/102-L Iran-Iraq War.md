number:	102
period:	L
name:	Iran-Iraq War\*
side:	none
OPS:	2

^name:
^src:

scoring:	false
war:		true
unique:		true
continuous:	false

	print: [img url]

Iran or Iraq invades the other (player's choice). Roll one die and subtract 1 for every opponent-controlled country adjacent to target of invasion. Player Victory on modified die roll of 4-6. Player adds 2 to Military Ops Track.

**Effects of Victory:** Player gains 2 VP and replaces opponent's Influence in target country with his own.

	oracle: [img url]

Gain 2 military operations.

Choose `Iran` or `Iraq`.

Roll a die and subtract 1 for each enemy-controlled country adjacent to the chosen country. If the result is 4 or greater, gain 2 VP, remove all enemy influence from the chosen country, and place friendly influence there equal to the amount removed.
