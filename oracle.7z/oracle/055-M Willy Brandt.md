number:	055
period:	M
name:	Willy Brandt\*
side:	USSR
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	true

	print: [img url]

USSR gains 1 VP.

USSR receives 1 Influence in West Germany.

Cancels *NATO* for West Germany.

*This event unplayable and/or canceled by 'Tear Down This Wall.'*

	oracle: [img url]

Award USSR 1 VP.

Place 1 USSR influence in `West Germany`.

*Ongoing* — *NATO* does not apply to `West Germany`.

*(This card instead does nothing during `096-L Tear Down This Wall`.)*

*(`096-L Tear Down This Wall` ends this event.)*
