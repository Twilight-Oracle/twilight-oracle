number:	079
period:	M
name:	Africa Scoring
side:	none
OPS:	-

^name:	-
^src:	-

scoring:	true
war:		false
unique:		false
continuous:	false

	print: [img url]

-

	oracle: [img url]

Score `Africa`.