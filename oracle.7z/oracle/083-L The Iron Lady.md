number:	083
period:	L
name:	The Iron Lady\*
side:	USA
OPS:	3

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	true

	print: [img url]

US gains 1 VP.

Add 1 USSR Influence in Argentina. Remove all USSR Influence from UK.

*Socialist Governments* event no longer playable.

	oracle: [img url]

Award USA 1 VP. Remove all USSR influence from `U.K.`.

Place 1 USSR influence in `Argentina`.

*Ongoing* — `007-E Socialist Governments` does nothing.
