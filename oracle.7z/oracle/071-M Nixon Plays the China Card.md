number:	071
period:	M
name:	Nixon Plays the China Card\*
side:	USA
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

If US has *The China Card*, gain 2 VP. Otherwise, US player receives *The China Card* now, face down and unavailable for immediate play.

	oracle: [img url]

If USA holds `006-E The China Card`, award USA 2 VP.

USA now holds `006-E The China Card`. Turn it facedown if it was taken from USSR.
