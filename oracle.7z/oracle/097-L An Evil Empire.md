number:	097
period:	L
name:	An Evil Empire\*
side:	3
OPS:	USA

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	true

	print: [img url]

Cancels/prevents *Flower Power*.

US gains 1 VP.

	oracle: [img url]

Award USA 1 VP.

End `059-M Flower Power`.

*Ongoing* — `059-M Flower Power` does nothing.
