number:	109
period:	L
name:	Yuri and Samantha\*
side:	USSR
OPS:	2

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

USSR receives 1 VP for each US coup attempt made for the remainder of the current turn.

	oracle: [img url]

Until end of turn, after USA launches a coup, award USSR 1 VP.
