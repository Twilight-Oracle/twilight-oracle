number:	023
period:	E
name:	Marshall Plan\*
side:	USA
OPS:	4

^name:	-
^src:	-

scoring:	false
war:		false
unique:		true
continuous:	true

	print: [img url]

Allows play of *NATO*.

Add one US Influence in each of seven non-USSR Controlled Western European countries.

	oracle: [img url]

Place 1 USA influence in each of up to 7 countries in `Western Europe` that are not USSR-controlled.

*Ongoing* — `021-E NATO` can not be resolved.