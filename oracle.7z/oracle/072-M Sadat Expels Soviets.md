number:	072
period:	M
name:	Sadat Expels Soviets\*
side:	USA
OPS:	1

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Remove all USSR Influence in Egypt and add one US Influence.

	oracle: [img url]

Remove all USSR influence from `Egypt`, then place 1 USA influence there.
