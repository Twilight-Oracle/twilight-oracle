number:	011
period:	E
name:	Korean War\*
side:	USSR
OPS:	2

^name:	-
^src:	-

scoring:	false
war:		true
unique:		true
continuous:	false

	print: [img url]

North Korea invades South Korea. Roll one die and subtract 1 for every US Controlled country adjacent to South Korea. USSR Victory on modified die roll 4-6. USSR adds 2 to Military Ops Track.

**Effects of Victory:** USSR gains 2 VP and replaces all US Influence in South Korea with USSR Influence.

	oracle: [img url]

Award USSR 2 military operations.

Roll a die and subtract 1 for each USA-controlled country adjacent to `South Korea`. If the result is 4 or greater, award 2 VP to USSR, remove all USA influence from `South Korea`, and place USSR influence there equal to the amount removed.