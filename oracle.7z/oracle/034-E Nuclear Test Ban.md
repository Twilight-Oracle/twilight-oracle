number:	034
period:	E
name:	Nuclear Test Ban
side:	none
OPS:	4

^name:	-
^src:	-

scoring:	false
war:		false
unique:		false
continuous:	false

	print: [img url]

Player earns VPs equal to current DEFCON level minus 2, then improve DEFCON two levels.

	oracle: [img url]

Gain VP equal to DEFCON minus 2.

Increment DEFCON twice.