number:	022
period:	E
name:	Independent Reds\*
side:	USA
OPS:	2

^name:	-
^src:	-

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

Add sufficient US Influence in either Yugoslavia, Romania, Bulgaria, Hungary or Czechoslovakia to equal USSR Influence.

	oracle: [img url]

Choose one of `Yugoslavia`, `Romania`, `Bulgaria`, `Hungary`, or `Czechoslovakia`. Place USA influence in the chosen country sufficient to equal USSR influence there.