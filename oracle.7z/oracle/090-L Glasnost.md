number:	090
period:	L
name:	Glasnost\*
side:	USSR
OPS:	4

^name:
^src:

scoring:	false
war:		false
unique:		true
continuous:	false

	print: [img url]

USSR gains 2 VP.

Improve DEFCON one level.

If *The Reformer* is in effect, then the USSR may place Influence or attempt Realignments as if they played a 4 Ops card.

	oracle: [img url]

Increment DEFCON, then award USSR 2 VP.

*(`087-L The Reformer` allows USSR to spread influence or perform realignments when this card is resolved.)*
