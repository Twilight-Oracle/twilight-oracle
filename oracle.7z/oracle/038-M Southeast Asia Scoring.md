number:	038
period:	M
name:	Southeast Asia Scoring\*
side:	none
OPS:	-

^name:	-
^src:	-

scoring:	true
war:		false
unique:		true
continuous:	false

	print: [img url]

-

	oracle: [img url]

Score `Southeast Asia`.